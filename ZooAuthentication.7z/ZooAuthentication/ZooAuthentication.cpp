// ZooAuthentication.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include "UserInfo.h"
#include "MD5.h"
using namespace std;

/*int numberOfAttempts = 0;
bool passCorrect = false;
string exit = "run";*/



/*
// read file
void readFile() {
    ifstream inputFile;
    string name;
    inputFile.open("test file.txt");

    cout << "reading data from the file. \n";

    inputFile >> name;
    cout << name << endl;

    inputFile.close();
}*/

int main()
{
    string userId;
    string userPass;
    UserInfo myUser = UserInfo();


        cout << "***WELCOME*** \n";
        cout << "Enter User ID \n";
        cin >> userId;
        myUser.setUserId(userId);

        cout << "Enter Password: \n";
        cin >> userPass;
        myUser.setUserPass(userPass);

        //Hash Password
        string original = md5(userPass);

        cout << "MD5 of User : " << original << endl;




    

}

/*
hashlib::sha1 h;

assert(h.hexdigest() == "da39a3ee5e6b4b0d3255bfef95601890afd80709");

h.update("C-string");
h.update(std::string());

auto h2 = h;

assert(h2 == h);                    // hasher is equationally complete
assert(h2.digest() == h.digest());  // semantics same as above

h.update(buf, sizeof(buf));         // sized input

assert(h.digest() == h.digest());   // can get result multiple times

using rmd160 = hashlib::hasher<rmd160_provider>;  // user-defined*/